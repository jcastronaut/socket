import React from "react";

const Chat = () => {
  return <h1>Chat</h1>;
};

export default Chat;
