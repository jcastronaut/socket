import React from "react";

const Join = () => {
  return <h1>Join</h1>;
};

export default Join;
